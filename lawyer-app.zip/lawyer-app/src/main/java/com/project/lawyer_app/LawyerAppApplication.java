package com.project.lawyer_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LawyerAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(LawyerAppApplication.class, args);
	}

}
